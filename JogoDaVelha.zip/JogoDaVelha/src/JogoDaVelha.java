import java.util.InputMismatchException;
import java.util.Scanner;

public class JogoDaVelha {
    private Casa[][] grade;

    public enum Casa {
        VAZIA, JOGADOR1, JOGADOR2
    }

    public JogoDaVelha() {
        grade = new Casa[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                grade[i][j] = Casa.VAZIA;
            }
        }
    }

    public void exibirGrade() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(simbolo(grade[i][j]));
                if (j < 2) {
                    System.out.print(" | ");
                }
            }
            System.out.println();
            if (i < 2) {
                System.out.println("---------");
            }
        }
    }

    private String simbolo(Casa casa) {
        switch (casa) {
            case VAZIA:
                return " ";
            case JOGADOR1:
                return "X";
            case JOGADOR2:
                return "O";
            default:
                return "";
        }
    }

    public void jogar() {
        Casa jogador = Casa.JOGADOR1;
        Scanner scanner = new Scanner(System.in);

        while (true) {
            exibirGrade();
            System.out.println("Jogador " + jogador.name() + ", faça sua jogada (linha coluna):");

            try {
                int linha = scanner.nextInt();
                int coluna = scanner.nextInt();

                if (movimentoValido(linha, coluna)) {
                    grade[linha][coluna] = jogador;

                    if (verificarVitoria(jogador)) {
                        exibirGrade();
                        System.out.println("Jogador " + jogador.name() + " venceu!");
                        break;
                    } else if (verificarEmpate()) {
                        exibirGrade();
                        System.out.println("Empate!");
                        break;
                    } else {
                        jogador = (jogador == Casa.JOGADOR1) ? Casa.JOGADOR2 : Casa.JOGADOR1;
                    }
                } else {
                    System.out.println("Movimento inválido. Tente novamente.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Entrada inválida. Insira um número inteiro para a linha e a coluna.");
                scanner.next(); // Limpar o buffer do scanner
            }
        }
    }

    private boolean movimentoValido(int linha, int coluna) {
        return linha >= 0 && linha < 3 && coluna >= 0 && coluna < 3 && grade[linha][coluna] == Casa.VAZIA;
    }

    private boolean verificarVitoria(Casa jogador) {
        for (int i = 0; i < 3; i++) {
            if (grade[i][0] == jogador && grade[i][1] == jogador && grade[i][2] == jogador) {
                return true;
            }
            if (grade[0][i] == jogador && grade[1][i] == jogador && grade[2][i] == jogador) {
                return true;
            }
        }
        if (grade[0][0] == jogador && grade[1][1] == jogador && grade[2][2] == jogador) {
            return true;
        }
        if (grade[0][2] == jogador && grade[1][1] == jogador && grade[2][0] == jogador) {
            return true;
        }
        return false;
    }

    private boolean verificarEmpate() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (grade[i][j] == Casa.VAZIA) {
                    return false;
                }
            }
        }
        return true;
    }

    public static void main(String[] args) {
        JogoDaVelha jogo = new JogoDaVelha();
        jogo.jogar();
    }
}
