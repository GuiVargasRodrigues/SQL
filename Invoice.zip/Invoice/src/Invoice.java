public class Invoice {
    private String numeroItem;
    private String descricaoItem;
    private int quantidadeItem;
    private double precoUnitario;

    // Construtor
    public Invoice(String numeroItem, String descricaoItem, int quantidadeItem, double precoUnitario) {
        this.numeroItem = numeroItem;
        this.descricaoItem = descricaoItem;
        // Verifica se a quantidade é positiva, senão configura como 0
        this.quantidadeItem = quantidadeItem > 0 ? quantidadeItem : 0;
        // Verifica se o preço unitário é positivo, senão configura como 0.0
        this.precoUnitario = precoUnitario > 0 ? precoUnitario : 0.0;
    }

    // Método para calcular o valor da fatura
    public double getInvoiceAmount() {
        return quantidadeItem * precoUnitario;
    }

    // Métodos getter e setter para cada variável de instância
    public String getNumeroItem() {
        return numeroItem;
    }

    public void setNumeroItem(String numeroItem) {
        this.numeroItem = numeroItem;
    }

    public String getDescricaoItem() {
        return descricaoItem;
    }

    public void setDescricaoItem(String descricaoItem) {
        this.descricaoItem = descricaoItem;
    }

    public int getQuantidadeItem() {
        return quantidadeItem;
    }

    public void setQuantidadeItem(int quantidadeItem) {
        // Verifica se a quantidade é positiva, senão configura como 0
        this.quantidadeItem = quantidadeItem > 0 ? quantidadeItem : 0;
    }

    public double getPrecoUnitario() {
        return precoUnitario;
    }

    public void setPrecoUnitario(double precoUnitario) {
        // Verifica se o preço unitário é positivo, senão configura como 0.0
        this.precoUnitario = precoUnitario > 0 ? precoUnitario : 0.0;
    }

    // Método main para testar a classe Invoice
    public static void main(String[] args) {
        // Criando uma instância de Invoice
        Invoice fatura = new Invoice("001", "Teclado USB", 2, 25.5);

        // Imprimindo os detalhes da fatura
        System.out.println("Número do item: " + fatura.getNumeroItem());
        System.out.println("Descrição do item: " + fatura.getDescricaoItem());
        System.out.println("Quantidade comprada: " + fatura.getQuantidadeItem());
        System.out.println("Preço unitário: $" + fatura.getPrecoUnitario());
        System.out.println("Valor total da fatura: $" + fatura.getInvoiceAmount());
    }
}

