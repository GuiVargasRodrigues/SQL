public class Invoice {
    private int numeroItem;
    private String descricaoItem;
    private int quantidade;
    private double precoUnitario;

    // Construtor
    public Invoice(int numeroItem, String descricaoItem, int quantidade, double precoUnitario) {
        this.numeroItem = numeroItem;
        this.descricaoItem = descricaoItem;
        if (quantidade > 0)
            this.quantidade = quantidade;
        else
            this.quantidade = 0;

        if (precoUnitario > 0.0)
            this.precoUnitario = precoUnitario;
        else
            this.precoUnitario = 0.0;
    }

    // Método para configurar o número do item faturado
    public void setNumeroItem(int numeroItem) {
        this.numeroItem = numeroItem;
    }

    // Método para obter o número do item faturado
    public int getNumeroItem() {
        return numeroItem;
    }

    // Método para configurar a descrição do item
    public void setDescricaoItem(String descricaoItem) {
        this.descricaoItem = descricaoItem;
    }

    // Método para obter a descrição do item
    public String getDescricaoItem() {
        return descricaoItem;
    }

    // Método para configurar a quantidade comprada do item
    public void setQuantidade(int quantidade) {
        if (quantidade > 0)
            this.quantidade = quantidade;
        else
            this.quantidade = 0;
    }

    // Método para obter a quantidade comprada do item
    public int getQuantidade() {
        return quantidade;
    }

    // Método para configurar o preço unitário do item
    public void setPrecoUnitario(double precoUnitario) {
        if (precoUnitario > 0.0)
            this.precoUnitario = precoUnitario;
        else
            this.precoUnitario = 0.0;
    }

    // Método para obter o preço unitário do item
    public double getPrecoUnitario() {
        return precoUnitario;
    }

    // Método para calcular o valor da fatura
    public double getValorFatura() {
        return quantidade * precoUnitario;
    }

    // Método principal para teste
    public static void main(String[] args) {
        Invoice fatura = new Invoice(101, "Teclado", 2, 50.0);

        System.out.println("Número do Item: " + fatura.getNumeroItem());
        System.out.println("Descrição do Item: " + fatura.getDescricaoItem());
        System.out.println("Quantidade: " + fatura.getQuantidade());
        System.out.println("Preço Unitário: " + fatura.getPrecoUnitario());
        System.out.println("Valor da Fatura: " + fatura.getValorFatura());
    }
}
