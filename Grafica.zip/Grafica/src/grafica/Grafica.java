package grafica;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

// Classe para representar um usuário genérico
class Usuario {
    private String nome;
    private String cpf;

    public Usuario(String nome, String cpf) {
        this.nome = nome;
        this.cpf = cpf;
    }

    // Getters e setters
    // ...
}

// Enum para representar os tipos de usuários
enum TipoUsuario {
    GERENTE, EMPREGADO, EMPREGADO_TERCEIRIZADO
}

// Classe para representar um gerente
class Gerente extends Usuario {
    private String setor;

    public Gerente(String nome, String cpf, String setor) {
        super(nome, cpf);
        this.setor = setor;
    }

    // Getters e setters
    // ...
}

// Classe para representar um empregado
class Empregado extends Usuario {
    private String funcao;

    public Empregado(String nome, String cpf, String funcao) {
        super(nome, cpf);
        this.funcao = funcao;
    }

    // Getters e setters
    // ...
}

// Classe para representar um empregado terceirizado
class EmpregadoTerceirizado extends Usuario {
    private String atividade;

    public EmpregadoTerceirizado(String nome, String cpf, String atividade) {
        super(nome, cpf);
        this.atividade = atividade;
    }

    // Getters e setters
    // ...
}

// Enum para representar os tipos de produto
enum TipoProduto {
    BANNER, REVISTA, MATERIAL_PUBLICITARIO, LIVRO, OUTRO
}

// Classe para representar um produto a ser impresso
class Produto {
    private TipoProduto tipo;
    private double preco;

    public Produto(TipoProduto tipo, double preco) {
        this.tipo = tipo;
        this.preco = preco;
    }

    // Getters e setters
    // ...
}

// Classe para representar um pedido
class Pedido {
    private Date dataEmissao;
    private Date dataFinalizacao;
    private double preco;
    private Usuario responsavelVenda;
    private List<Produto> produtos;

    public Pedido(Date dataEmissao, Usuario responsavelVenda, List<Produto> produtos) {
        this.dataEmissao = dataEmissao;
        this.responsavelVenda = responsavelVenda;
        this.produtos = produtos;
        // Calcula o preço total do pedido baseado nos produtos
        this.preco = calcularPrecoTotal();
    }

    private double calcularPrecoTotal() {
        double total = 0;
        for (Produto produto : produtos) {
            total += produto.getPreco();
        }
        return total;
    }

    // Getters e setters
    // ...
}

// Classe para representar um funcionário da produção
class FuncionarioProducao extends Usuario {
    private Pedido pedidoProducao;

    public FuncionarioProducao(String nome, String cpf) {
        super(nome, cpf);
    }

    public void setPedidoProducao(Pedido pedidoProducao) {
        this.pedidoProducao = pedidoProducao;
    }

    // Getters e setters
    // ...
}

public class Grafica {
    public static void main(String[] args) {
        // Criando instâncias de gerentes
        Gerente gerenteProducao = new Gerente("João", "123456789", "Produção");
        Gerente gerenteVendas = new Gerente("Maria", "987654321", "Vendas");

        // Criando instâncias de empregados
        Empregado empregado1 = new Empregado("Carlos", "111222333", "Operador de Máquina");
        Empregado empregado2 = new Empregado("Ana", "444555666", "Design Gráfico");

        // Criando instâncias de empregados terceirizados
        EmpregadoTerceirizado terceirizado1 = new EmpregadoTerceirizado("José", "777888999", "Limpeza");
        EmpregadoTerceirizado terceirizado2 = new EmpregadoTerceirizado("Marta", "111222333", "Alimentação");

        // Criando produtos
        Produto banner = new Produto(TipoProduto.BANNER, 50.0);
        Produto livro = new Produto(TipoProduto.LIVRO, 20.0);

        // Criando lista de produtos para um pedido
        List<Produto> produtosPedido1 = new ArrayList<>();
        produtosPedido1.add(banner);
        produtosPedido1.add(livro);

        // Criando um pedido
        Pedido pedido1 = new Pedido(new Date(), gerenteVendas, produtosPedido1);

        // Criando funcionários da produção
        FuncionarioProducao funcionario1 = new FuncionarioProducao("Pedro", "999888777");
        FuncionarioProducao funcionario2 = new FuncionarioProducao("Luiza", "666555444");

        // Atribuindo pedido à produção
        funcionario1.setPedidoProducao(pedido1);

        // Exemplo de uso dos objetos criados
        System.out.println("Nome do gerente de produção: " + gerenteProducao.getNome());
        System.out.println("Função do empregado 1: " + empregado1.getFuncao());
        System.out.println("Atividade do terceirizado 2: " + terceirizado2.getAtividade());
        System.out.println("Quantidade de produtos no pedido 1: " + pedido1.getProdutos().size());
        System.out.println("Preço total do pedido 1: " + pedido1.getPreco());

        // Poderíamos continuar manipulando os objetos conforme a lógica do sistema da gráfica.
    }
}

